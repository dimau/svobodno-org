<fieldset class="edited left social">
    <legend>
        Страницы в социальных сетях
    </legend>
    <table>
        <tbody>
            <tr title="Скопируйте ссылку из адресной строки браузера при просмотре своей личной страницы в социальной сети">
                <td class="itemLabel">
                    <img src="img/vkontakte.jpg">
                </td>
                <td class="itemRequired">
                </td>
                <td class="itemBody">
                    <input type="text" name="vkontakte" id="vkontakte"
                           placeholder="http://vk.com/..." <?php echo "value='".$userCharacteristic['vkontakte']."'";?>>
                </td>
            </tr>
            <tr title="Скопируйте ссылку из адресной строки браузера при просмотре своей личной страницы в социальной сети">
                <td class="itemLabel">
                    <img src="img/odnoklassniki.png">
                </td>
                <td class="itemRequired">
                </td>
                <td class="itemBody">
                    <input type="text" name="odnoklassniki" id="odnoklassniki"
                           placeholder="http://www.odnoklassniki.ru/profile/..." <?php echo "value='".$userCharacteristic['odnoklassniki']."'";?>>
                </td>
            </tr>
            <tr title="Скопируйте ссылку из адресной строки браузера при просмотре своей личной страницы в социальной сети">
                <td class="itemLabel">
                    <img src="img/facebook.jpg">
                </td>
                <td class="itemRequired">
                </td>
                <td class="itemBody">
                    <input type="text" name="facebook" id="facebook"
                           placeholder="https://www.facebook.com/profile.php?..." <?php echo "value='".$userCharacteristic['facebook']."'";?>>
                </td>
            </tr>
            <tr title="Скопируйте ссылку из адресной строки браузера при просмотре своей личной страницы в социальной сети">
                <td class="itemLabel">
                    <img src="img/twitter.png">
                </td>
                <td class="itemRequired">
                </td>
                <td class="itemBody">
                    <input type="text" name="twitter" id="twitter"
                           placeholder="https://twitter.com/..." <?php echo "value='".$userCharacteristic['twitter']."'";?>>
                </td>
            </tr>
        </tbody>
    </table>
</fieldset>

    <div class="clearBoth"></div>
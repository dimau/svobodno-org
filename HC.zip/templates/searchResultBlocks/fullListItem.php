<div class='realtyObject' propertyId='{propertyId}'>
    <div class="serviceMarks">
        <div class='numberOfRealtyObject'>{number}</div>
        {favorites}
    </div>
    <div class="overFotosWrapper">
        {fotosWrapper}
    </div>
    <div class="mainContent"><div class="address"><span class="typeOfObjectString">{typeOfObject}</span><span class="districtString">{district}</span><a class="linkToDescription" href="property.php?propertyId={propertyId}" target="_blank">{address}</a></div><div class="amountOfRooms">{amountOfRooms}{adjacentRooms}</div><div class="areaValues">{areaValues}</div><div class="floor">{floor}</div><div class="furniture">{furniture}</div><div class="costOfRenting">{costOfRenting}{utilities}</div><div class="clearBoth"></div></div>
    <div class="clearBoth"></div>
</div>
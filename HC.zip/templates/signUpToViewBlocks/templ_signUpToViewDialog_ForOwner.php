<div id="signUpToViewDialog" title="Записаться на просмотр">

    <div style="text-align: left; margin: 10px 0 10px 0;">Для отправки заявки на просмотр необходимо</div>
    <div style="text-align: left; margin: 10px 0 10px 0;">Указать параметры поиска недвижимости в <a href="personal.php?tabsId=4">Личном кабинете</a></div>

</div>
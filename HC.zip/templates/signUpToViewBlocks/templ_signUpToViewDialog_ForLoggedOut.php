<div id="signUpToViewDialog" title="Записаться на просмотр">

    <div style="text-align: left; margin: 10px 0 10px 0;">Для отправки заявки на просмотр необходимо</div>
    <div style="text-align: center; margin: 10px 0 10px 0;"><a href="login.php">Войти</a> или <a href="registration.php?typeTenant=TRUE">Зарегистрироваться</a></div>

    <div class="localHeader">Регистрация позволит:</div>
    <ul class="benefits" style="text-align: left;">
        <li>
            Записаться на просмотр любой недвижимости
        </li>
        <li>
            Получать уведомления о появлении подходящих вариантов недвижимости
        </li>
        <li>
            Добавлять объявления в избранные и в любой момент просматривать их
        </li>
        <li>
            Не указывать повторно условия поиска - портал все запомнит
        </li>
    </ul>

</div>